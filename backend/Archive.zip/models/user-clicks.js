// const mongoose = require('mongoose');

// const visitCountSchema = mongoose.Schema({
//   postId: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: 'Post', // Reference to your Post model
//   },
//   visitCount: {
//     type: Number,
//     default: 1
//   }
// })

// module.exports = mongoose.model('UserClicks', visitCountSchema);
